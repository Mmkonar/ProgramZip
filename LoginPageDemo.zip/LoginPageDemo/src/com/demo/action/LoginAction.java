package com.demo.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;

import com.demo.forms.LoginForm;

public class LoginAction extends org.apache.struts.action.Action {

	private final static String SUCCESS = "success";
	private final static String FAILURE = "failure";

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String userName= "";
		String password ="";
		
		//userName= request.getParameter("userName");
		//Set form using ActionForm.
		LoginForm loginForm = (LoginForm) form;
		userName = loginForm.getUserName();
		password = loginForm.getPassword();
		System.out.println(" ACTION FORM: User name: " + userName
				+ " password:" + password);
		
		loginForm.setMessage("Welcome 1123 ");
		
		
		//Set form using DynaActionForm.
		/*DynaActionForm loginForm = (DynaActionForm) form;
		userName = loginForm.get("userName").toString();
		password = loginForm.get("password").toString();
		System.out.println(" ACTION FORM: User name: " + userName
				+ " password:" + password);*/
		
		
		if (userName.equals(password)) {
			return mapping.findForward(SUCCESS);
		} else {
			return mapping.findForward(FAILURE);
		}
	}
}
