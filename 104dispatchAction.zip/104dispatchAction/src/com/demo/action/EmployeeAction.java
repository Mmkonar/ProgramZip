package com.demo.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.demo.forms.EmployeeForm;

public class EmployeeAction extends DispatchAction {

	private final static String SUCCESS = "success";

	public ActionForward add(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		EmployeeForm employeeForm = (EmployeeForm) form;
		employeeForm.setMessage("Employee added successfully");
		return mapping.findForward(SUCCESS);
	}

	public ActionForward update(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		EmployeeForm employeeForm = (EmployeeForm) form;
		employeeForm.setMessage("Employee updated successfully");
		return mapping.findForward(SUCCESS);
	}

	public ActionForward delete(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		EmployeeForm employeeForm = (EmployeeForm) form;
		employeeForm.setMessage("Employee deleted successfully");
		return mapping.findForward(SUCCESS);
	}

}
