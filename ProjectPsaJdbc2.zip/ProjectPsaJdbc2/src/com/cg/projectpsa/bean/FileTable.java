package com.cg.projectpsa.bean;

import java.io.File;

public class FileTable {
	private String projectId;
	private String projectName;
	private String osName;
	private String jdkVersion;
	private File dependancies;

	public String getOsName() {
		return osName;
	}

	public void setOsName(String osName) {
		this.osName = osName;
	}

	public String getJdkVersion() {
		return jdkVersion;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public void setJdkVersion(String jdkVersion) {
		this.jdkVersion = jdkVersion;
	}

	public File getDependancies() {
		return dependancies;
	}

	public void setDependancies(File dependancies) {
		this.dependancies = dependancies;
	}

	public FileTable() {
		super();
	}
}