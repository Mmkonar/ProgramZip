package com.cg.projectpsa.dao;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.projectpsa.bean.FileTable;
import com.cg.projectpsa.util.DatabaseConnection;

public class ProjectDAOImpl implements IProjectDAO {
	Connection con;

	public ProjectDAOImpl() {
		con = DatabaseConnection.getConnection();
	}

//	create table filetable1(project_id primary key varchar2(20), dependencies clob, jdk_version varchar2(10), os_version varchar2(20), project_name varchar2(20));

	@Override
	public FileTable insert(FileTable file) {
		String sql = "insert into filetable1 values(?,?,?,?,?)";
		try {
			PreparedStatement statement = con.prepareStatement(sql);
			statement.setString(1, file.getProjectId());
			statement.setCharacterStream(2, new FileReader(file.getDependancies()), file.getDependancies().length());
			statement.setString(3, file.getJdkVersion());
			statement.setString(4, file.getOsName());
			statement.setString(5, file.getProjectName());
			statement.executeUpdate();
		} catch (SQLException | FileNotFoundException e) {
			e.printStackTrace();
		}
		return file;
	}

	@Override
	public Clob getAccountList(String projectId) {
		Clob c = null;
		try {
			PreparedStatement ps = con.prepareStatement("select * from filetable1 where project_id=?");
			ps.setString(1, projectId);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString(1));
				System.out.println(rs.getClob(2));
				System.out.println(rs.getString(3));
				System.out.println(rs.getString(4));
				System.out.println(rs.getString(5));
				c = rs.getClob(2);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return c;
	}

}
