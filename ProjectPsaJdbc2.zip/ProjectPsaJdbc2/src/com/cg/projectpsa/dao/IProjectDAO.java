package com.cg.projectpsa.dao;

import java.sql.Clob;

import com.cg.projectpsa.bean.FileTable;

public interface IProjectDAO {
	public Clob getAccountList(String token);

	FileTable insert(FileTable cust);
}
