package com.cg.projectpsa.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

	public static Connection getConnection() {
		Connection con = null;
		String url = "jdbc:oracle:thin:@10.51.103.201:1521:orcl11g";
		String user = "lab2etrg24";
		String pwd = "lab2eoracle";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(url, user, pwd);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

}
