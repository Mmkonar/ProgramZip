package com.cg.projectpsa.service;

import java.sql.Clob;

import com.cg.projectpsa.bean.FileTable;
import com.cg.projectpsa.dao.IProjectDAO;
import com.cg.projectpsa.dao.ProjectDAOImpl;

public class ProjectServiceImpl implements IProjectService {
	IProjectDAO dao;

	public ProjectServiceImpl() {
		dao = new ProjectDAOImpl();
	}

	@Override
	public Clob getAccountList(String projectId) {
		return dao.getAccountList(projectId);
	}

	@Override
	public FileTable insert(FileTable file) {
		return dao.insert(file);
	}

}
