package com.cg.projectpsa.service;

import java.sql.Clob;

import com.cg.projectpsa.bean.FileTable;

public interface IProjectService {
	FileTable insert(FileTable cust);

	public Clob getAccountList(String projectId);
}
