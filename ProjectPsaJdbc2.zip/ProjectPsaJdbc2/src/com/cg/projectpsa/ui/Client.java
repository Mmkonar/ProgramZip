package com.cg.projectpsa.ui;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.StringTokenizer;

import com.cg.projectpsa.bean.FileTable;
import com.cg.projectpsa.service.IProjectService;
import com.cg.projectpsa.service.ProjectServiceImpl;

public class Client {
	public static void main(String[] args) {
		// get path of project
		String name = System.getProperty("user.dir");
		System.out.println(name);
		StringTokenizer st = new StringTokenizer(name, "\\");
		String projectName = null;
		while (st.hasMoreTokens()) {
			projectName = st.nextToken();
		}
		System.out.println(projectName);
		try {
			// command of jdeps to get class level dependencies
			Runtime.getRuntime().exec("cmd /c start cmd.exe /K \"jdeps -dotoutput Jdeps112 \n" + name + "\"");
		} catch (Exception e) {
			System.out.println("HEY Buddy ! U r Doing Something Wrong ");
		}
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		File file = new File(name + "\\Jdeps112\\" + projectName + ".dot");
		// get OS name
		String os = System.getProperty("os.name");
		// get JDK version
		String version = System.getProperty("java.version");

		FileTable ft = new FileTable();
		ft.setOsName(os);
		ft.setJdkVersion(version);
		ft.setProjectId(projectName);
		ft.setProjectName(projectName);
		ft.setDependancies(file);
		IProjectService service = new ProjectServiceImpl();
		// insert into database
		service.insert(ft);
		// get from database with name
		Clob c = service.getAccountList(projectName);
		System.out.println("Want to download file");
		System.out.println("1. Yes");
		System.out.println("2. No");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		if (choice == 1)
			createFile(c, projectName);
	}

	static void createFile(Clob c, String projectName) {
		try {
			Reader r = c.getCharacterStream();
			FileWriter fw = new FileWriter("D:\\" + projectName + ".txt");
			int i;
			while ((i = r.read()) != -1)
				fw.write((char) i);

			fw.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
