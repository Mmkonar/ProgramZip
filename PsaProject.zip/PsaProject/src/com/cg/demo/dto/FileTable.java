package com.cg.demo.dto;

import java.util.Arrays;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "filetable")
public class FileTable {

	@Id
	@Column(name = "project_id")
	private String projectId;

	@Column(name = "project_name")
	private String projectName;
	
	@Column(name = "os_version")
	private String osName;

	@Column(name = "jdk_version")
	private String jdkVersion;

	@Lob
	@Basic(fetch = FetchType.LAZY)
	@Column(name = "dependancies", columnDefinition = "BLOB", nullable = false)
	private byte[] dependancies;

	public FileTable(String projectId, String projectName, String osName, String jdkVersion, byte[] dependancies) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
		this.osName = osName;
		this.jdkVersion = jdkVersion;
		this.dependancies = dependancies;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getOsName() {
		return osName;
	}

	public void setOsName(String osName) {
		this.osName = osName;
	}

	public String getJdkVersion() {
		return jdkVersion;
	}

	public void setJdkVersion(String jdkVersion) {
		this.jdkVersion = jdkVersion;
	}

	public byte[] getDependancies() {
		return dependancies;
	}

	public void setDependancies(byte[] dependancies) {
		this.dependancies = dependancies;
	}

	@Override
	public String toString() {
		return projectId;
	}

	public FileTable() {
		super();
		// TODO Auto-generated constructor stub
	}

}
