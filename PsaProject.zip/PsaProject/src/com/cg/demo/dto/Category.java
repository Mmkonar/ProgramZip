package com.cg.demo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


	@Entity
	@Table(name="category")
	public class Category {
		
		@Id
		@Column(name="cid")
		private String catId;
		
		@Column(name="cdesc")
		private String cname;

		
		public Category() {
			
		}

		public Category(String catId, String cname) {
			super();
			this.catId = catId;
			this.cname = cname;
		}

		public String getCatId() {
			return catId;
		}

		public void setCatId(String catId) {
			this.catId = catId;
		}

		public String getCname() {
			return cname;
		}

		public void setCname(String cname) {
			this.cname = cname;
		}

		@Override
		public String toString() {
			return catId;
		}

		
		
		
		

	}


