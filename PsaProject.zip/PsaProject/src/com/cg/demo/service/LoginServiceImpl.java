package com.cg.demo.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.dao.IProjectDao;


import com.cg.demo.dto.Category;

@Service
public class LoginServiceImpl implements ILoginService
{

@Autowired
	IProjectDao projectDao= null;	
	public IProjectDao getLoginDao()
	{
		return projectDao;
	}

	public void setLoginDao(IProjectDao projectDao) 
	{
	this.projectDao = projectDao;
	}

	




	@Override
	public ArrayList<Category> fetchAllProject() {
		
		return projectDao.fetchAllProject();
	}

	@Override
	public Category fetchById(String getcatId) {
	
		return projectDao.fetchById(getcatId);
	}

	
	
	


}
