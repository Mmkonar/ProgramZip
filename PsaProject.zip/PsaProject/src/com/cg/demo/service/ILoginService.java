package com.cg.demo.service;

import java.util.ArrayList;


import com.cg.demo.dto.Category;


public interface ILoginService {
	

	

	
	public ArrayList<Category> fetchAllProject();
	public Category fetchById(String getcatId);
	
	

}
