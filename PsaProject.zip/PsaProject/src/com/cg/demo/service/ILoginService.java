package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.dto.FileTable;




public interface ILoginService {
	

	

	
	public ArrayList<FileTable> fetchAllProject();
	public FileTable fetchById(String getcatId);
	
	

}
