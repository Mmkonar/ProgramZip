package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.demo.dto.FileTable;




@Repository
@Transactional
public class ProjectDaoImpl  implements
IProjectDao
{

	@PersistenceContext
	EntityManager entityMgr=null;
	public EntityManager getEntityMgs() {
		return entityMgr;
	}
	public void setEntityMgs(EntityManager entityMgs) {
		this.entityMgr = entityMgs;
	}
	
	
	


	@Override
	public ArrayList<FileTable> fetchAllProject() {
		TypedQuery<FileTable> tq = entityMgr.createQuery("Select cus from FileTable cus", FileTable.class);
		ArrayList<FileTable> cusList = (ArrayList) tq.getResultList();
		System.out.println(cusList);
		return cusList;
	}
	@Override
	public FileTable fetchById(String getcatId) {
		FileTable obj=entityMgr.find(FileTable.class,getcatId);
		System.out.println(obj);
		return obj;

	}

		

}
