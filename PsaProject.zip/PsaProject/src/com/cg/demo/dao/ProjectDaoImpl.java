package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;



import com.cg.demo.dto.Category;

@Repository
@Transactional
public class ProjectDaoImpl  implements
IProjectDao
{

	@PersistenceContext
	EntityManager entityMgr=null;
	public EntityManager getEntityMgs() {
		return entityMgr;
	}
	public void setEntityMgs(EntityManager entityMgs) {
		this.entityMgr = entityMgs;
	}
	
	
	


	@Override
	public ArrayList<Category> fetchAllProject() {
		String selQ="SELECT cat FROM Category cat";
		TypedQuery<Category> tq=entityMgr.createQuery(selQ,Category.class);
		ArrayList<Category> uList=(ArrayList<Category>) tq.getResultList();
		return uList;
	}
	@Override
	public Category fetchById(String getcatId) {
		Category obj=entityMgr.find(Category.class,getcatId);
		return obj;
	}

		

}
