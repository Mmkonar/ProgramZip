package com.cg.demo.dao;

import java.util.ArrayList;



import com.cg.demo.dto.Category;

public interface IProjectDao {
	
	
		
	public ArrayList<Category> fetchAllProject();
	public Category fetchById(String getcatId);
}
	
