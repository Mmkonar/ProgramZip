package com.cg.demo.dao;

import java.util.ArrayList;

import com.cg.demo.dto.FileTable;




public interface IProjectDao {
	
	
		
	public ArrayList<FileTable> fetchAllProject();
	public FileTable fetchById(String getcatId);
}
	
