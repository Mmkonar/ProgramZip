package com.cg.demo.ctrl;

import java.time.LocalDate;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.demo.dto.Category;
import com.cg.demo.service.ILoginService;


@Controller
public class HelloController 
{

	@Autowired
	ILoginService logSer=null;
	
	public ILoginService getLogSer() {
		return logSer;
	}

	public void setLogSer(ILoginService logSer) {
		this.logSer = logSer;
	}
	@RequestMapping(value="/ShowHomepage")
		
	public String dispHomePage(Model model)
	{
		String today = " Today is"+LocalDate.now();
		model.addAttribute("todayObj",today);
		return "Home";
		
	}
	@RequestMapping("/ShowAllCategoryDetails")
	public String dispAlluserDetails(Model model)
	{
		ArrayList<Category> uList=logSer.fetchAllProject();
		model.addAttribute("UserListObj", uList);
		return "ListAllTrainee";
	}
	
		
	/******************************************************/
	@RequestMapping(value="/ShowProjectByName")
	public String RetriveTrainee(Model model)
	{
		Category tr=new Category();
		model.addAttribute("userObj", tr);
		
		ArrayList<Category> uList=logSer.fetchAllProject();
		model.addAttribute("UserListObj1", uList);
		
		return "RetriveProject";
		
	}
		
	/*******************************************************/
	@RequestMapping(value="/ShowRetrDataPage")
	public String retriveDetail(@ModelAttribute("retriveObj") Category tr1,
			Model model)
	{
		ArrayList<Category> uList=logSer.fetchAllProject();
		model.addAttribute("UserListObj1", uList);
		Category tr=new Category();
		model.addAttribute("userObj", tr);
		Category trg=logSer.fetchById(tr1.getCatId());
		model.addAttribute("TrgDetailObj", trg);
		/*ArrayList<Category> uList=logSer.fetchAllProject();
		model.addAttribute("UserListObj", uList);*/
		return "RetriveInfojsp";
	}
	
}

