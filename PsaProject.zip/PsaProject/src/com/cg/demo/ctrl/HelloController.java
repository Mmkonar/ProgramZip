package com.cg.demo.ctrl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.demo.dto.FileTable;
import com.cg.demo.service.ILoginService;





@Controller
public class HelloController 
{
	static String file = null;
	@Autowired
	ILoginService logSer=null;
	
	public ILoginService getLogSer() {
		return logSer;
	}

	public void setLogSer(ILoginService logSer) {
		this.logSer = logSer;
	}
	@RequestMapping(value="/ShowHomepage")
		
	public String dispHomePage(Model model)
	{
		String today = " Today is"+LocalDate.now();
		model.addAttribute("todayObj",today);
		return "Home";
		
	}
	@RequestMapping("/ShowAllCategoryDetails")
	public String dispAlluserDetails(Model model)
	{
		ArrayList<FileTable> uList=logSer.fetchAllProject();
		model.addAttribute("UserListObj", uList);
		return "ListAllTrainee";
	}
	
		
	/******************************************************/
	@RequestMapping(value="/ShowProjectByName")
	public String RetriveTrainee(Model model)
	{
		FileTable tr=new FileTable();
		model.addAttribute("userObj", tr);
		
		ArrayList<FileTable> uList=logSer.fetchAllProject();
		System.out.println(uList);
		model.addAttribute("UserListObj1", uList);
		
		return "RetriveProject";
		
	}
	
	
	/**
	 * @throws FileNotFoundException ****************************************************/
	@RequestMapping(value="/download")
	public String Download(HttpSession session,HttpServletResponse response,Model model) 
	{
		String filename = "D:\\file.txt";
		File file1 = new File(file);
		FileTable tr=new FileTable();
		model.addAttribute("userObj", tr);
		try {
			InputStream in = new FileInputStream(file1);
			response.setContentType("application/force-download");
			response.setHeader("Content-Disposition", "attachment;filename=file.txt");
			 IOUtils.copy(in, response.getOutputStream());
			response.flushBuffer();
			in.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		return "RetriveInfojsp";
		
	}
	/*******************************************************/
	@RequestMapping(value="/ShowRetrDataPage")
	public String retriveDetail(@ModelAttribute("userObj") FileTable tr1,
			Model model)
	{
		ArrayList<FileTable> uList=logSer.fetchAllProject();
		model.addAttribute("UserListObj1", uList);
		FileTable tr=new FileTable();
		System.out.println(tr1);
		model.addAttribute("userObj", tr);
		FileTable trg=logSer.fetchById(tr1.getProjectId());
		byte[] bytes = trg.getDependancies();
		writeByte(bytes);
		model.addAttribute("TrgDetailObj", trg);
		return "RetriveInfojsp";
	}
	
	static void writeByte(byte[] bytes) {
		try {
			
			 file = "D:\\file.txt";
			// Initialize a pointer
			// in file using OutputStream
			OutputStream os = new FileOutputStream(file);
			// Starts writing the bytes in it
			os.write(bytes);
			System.out.println("Successfully" + " byte inserted");
			// Close the file
			os.close();
		} catch (Exception e) {
			System.err.println("Exception: " + e);
		}
	}
	
}

